CREATE TRIGGER t_equipo_before_delete
BEFORE DELETE ON t_equipo
FOR EACH ROW
  BEGIN 
UPDATE t_version 
  SET ver=(1+ver) 
  WHERE  idv='3'; 
END;
