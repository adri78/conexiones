CREATE TRIGGER t_repuestos_before_insert
BEFORE INSERT ON t_repuestos
FOR EACH ROW
  BEGIN
 UPDATE  t_version 
  SET ver=(1+ver) 
  WHERE  idv='8';
END;
