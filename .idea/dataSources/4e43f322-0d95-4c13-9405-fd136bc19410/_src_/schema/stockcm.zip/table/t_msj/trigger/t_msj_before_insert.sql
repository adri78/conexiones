CREATE TRIGGER t_msj_before_insert
BEFORE INSERT ON t_msj
FOR EACH ROW
  BEGIN
 UPDATE  t_version 
  SET ver=(1+ver) 
  WHERE idv='9';
END;
